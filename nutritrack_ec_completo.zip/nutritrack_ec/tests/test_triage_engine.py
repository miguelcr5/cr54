"""
NUTRITRACK EC — Tests del TriajeEngine
Ejecutar con: pytest tests/test_triage_engine.py -v
"""

import pytest
from app.services.triage_engine import TriajeEngine, DatosTriaje

engine = TriajeEngine()


def base(**kwargs) -> DatosTriaje:
    """Niño sano base. Sobreescribir campos para cada test."""
    defaults = dict(
        zscore_talla_edad=0.0, zscore_peso_talla=0.0, zscore_peso_edad=0.0,
        muac_cm=14.0, velocidad_crecimiento=0,
        hemoglobina=12.0, peso_nacer_g=3200, semanas_gestacion=39,
        episodios_diarrea_mes=0, episodios_ira_mes=0,
        lactancia_exclusiva=2, enf_cronica_nivel=0,
        estado_consciencia=0, edema_nutricional=0, deshidratacion=0,
        vomitos_persistentes=0, convulsiones=False,
        dificultad_respiratoria=False, fiebre_alta=False,
        score_elcsa=0, acceso_agua=0, saneamiento=0,
        escolaridad_materna_anos=12, quintil_socioeconomico=3,
        zona_consulta=0, ivnt_score=0.0,
    )
    defaults.update(kwargs)
    return DatosTriaje(**defaults)


# ── NIVEL I: URGENCIA ───────────────────────────────────────────────────────

class TestUrgencia:

    def test_inconsciencia_activa_urgencia(self):
        r = engine.evaluar(base(estado_consciencia=3))
        assert r.nivel == 'urgencia'
        assert r.codigo == 'I'
        assert r.color == 'rojo'

    def test_letargia_activa_urgencia(self):
        r = engine.evaluar(base(estado_consciencia=2))
        assert r.nivel == 'urgencia'

    def test_convulsiones_activan_urgencia(self):
        r = engine.evaluar(base(convulsiones=True))
        assert r.nivel == 'urgencia'

    def test_dificultad_respiratoria_activa_urgencia(self):
        r = engine.evaluar(base(dificultad_respiratoria=True))
        assert r.nivel == 'urgencia'

    def test_kwashiorkor_severo_activa_urgencia(self):
        r = engine.evaluar(base(edema_nutricional=2))
        assert r.nivel == 'urgencia'

    def test_deshidratacion_severa_activa_urgencia(self):
        r = engine.evaluar(base(deshidratacion=2))
        assert r.nivel == 'urgencia'

    def test_zscore_pt_menor_3_activa_urgencia(self):
        r = engine.evaluar(base(zscore_peso_talla=-3.5))
        assert r.nivel == 'urgencia'

    def test_muac_critico_activa_urgencia(self):
        r = engine.evaluar(base(muac_cm=11.0))
        assert r.nivel == 'urgencia'

    def test_anemia_severa_activa_urgencia(self):
        r = engine.evaluar(base(hemoglobina=6.5))
        assert r.nivel == 'urgencia'

    def test_ivnt_extremo_activa_urgencia(self):
        r = engine.evaluar(base(ivnt_score=9.0))
        assert r.nivel == 'urgencia'

    def test_criterios_activados_no_vacio(self):
        r = engine.evaluar(base(estado_consciencia=3, muac_cm=11.0))
        assert len(r.criterios_activados) >= 2

    def test_disposicion_urgencia(self):
        r = engine.evaluar(base(convulsiones=True))
        assert 'urgencias' in r.disposicion.lower() or 'ahora' in r.disposicion.lower()


# ── NIVEL II: HOSPITALIZACIÓN ───────────────────────────────────────────────

class TestHospitalizacion:

    def test_irritabilidad_sin_urgencia_da_hospitalizacion(self):
        r = engine.evaluar(base(estado_consciencia=1))
        assert r.nivel == 'hospitalizacion'

    def test_edema_leve_da_hospitalizacion(self):
        r = engine.evaluar(base(edema_nutricional=1))
        assert r.nivel == 'hospitalizacion'

    def test_zscore_te_menor_3_da_hospitalizacion(self):
        r = engine.evaluar(base(zscore_talla_edad=-3.2))
        assert r.nivel == 'hospitalizacion'

    def test_ivnt_critico_da_hospitalizacion(self):
        r = engine.evaluar(base(ivnt_score=7.8))
        assert r.nivel == 'hospitalizacion'

    def test_fiebre_alta_con_desnutricion(self):
        r = engine.evaluar(base(fiebre_alta=True, zscore_talla_edad=-2.5))
        assert r.nivel == 'hospitalizacion'

    def test_codigo_II(self):
        r = engine.evaluar(base(edema_nutricional=1))
        assert r.codigo == 'II'


# ── NIVEL III: AMBULATORIO ──────────────────────────────────────────────────

class TestAmbulatorio:

    def test_ivnt_alto_da_ambulatorio(self):
        r = engine.evaluar(base(ivnt_score=5.5))
        assert r.nivel == 'ambulatorio'

    def test_desnutricion_cronica_da_ambulatorio(self):
        r = engine.evaluar(base(zscore_talla_edad=-2.3))
        assert r.nivel == 'ambulatorio'

    def test_diarrea_frecuente_da_ambulatorio(self):
        r = engine.evaluar(base(episodios_diarrea_mes=4))
        assert r.nivel == 'ambulatorio'

    def test_muac_bajo_da_ambulatorio(self):
        r = engine.evaluar(base(muac_cm=12.0))
        assert r.nivel == 'ambulatorio'

    def test_anemia_moderada_da_ambulatorio(self):
        r = engine.evaluar(base(hemoglobina=9.5))
        assert r.nivel == 'ambulatorio'

    def test_codigo_III(self):
        r = engine.evaluar(base(ivnt_score=6.0))
        assert r.codigo == 'III'


# ── NIVEL IV: ALTA CON SEGUIMIENTO ─────────────────────────────────────────

class TestCasa:

    def test_ivnt_moderado_da_alta_seguimiento(self):
        r = engine.evaluar(base(ivnt_score=3.2))
        assert r.nivel == 'casa'

    def test_anemia_leve_da_alta_seguimiento(self):
        r = engine.evaluar(base(hemoglobina=10.5))
        assert r.nivel == 'casa'

    def test_zscore_te_riesgo_da_alta_seguimiento(self):
        r = engine.evaluar(base(zscore_talla_edad=-1.5))
        assert r.nivel == 'casa'

    def test_inseguridad_alimentaria_moderada(self):
        r = engine.evaluar(base(score_elcsa=4))
        assert r.nivel == 'casa'

    def test_codigo_IV(self):
        r = engine.evaluar(base(ivnt_score=3.0))
        assert r.codigo == 'IV'

    def test_disposicion_menciona_casa(self):
        r = engine.evaluar(base(ivnt_score=3.0))
        assert 'casa' in r.disposicion.lower()


# ── NIVEL V: NORMAL ─────────────────────────────────────────────────────────

class TestNormal:

    def test_nino_sano_da_normal(self):
        r = engine.evaluar(base())
        assert r.nivel == 'normal'

    def test_codigo_V(self):
        r = engine.evaluar(base())
        assert r.codigo == 'V'

    def test_color_azul(self):
        r = engine.evaluar(base())
        assert r.color == 'azul'

    def test_sin_alertas_criticas(self):
        r = engine.evaluar(base())
        criticas = [a for a in r.alertas if a['nivel'] == 'CRITICO']
        assert len(criticas) == 0

    def test_disposicion_menciona_bien(self):
        r = engine.evaluar(base())
        assert 'bien' in r.disposicion.lower() or 'rutinario' in r.disposicion.lower()


# ── PRIORIDAD EN CASCADA ────────────────────────────────────────────────────

class TestCascada:

    def test_urgencia_supera_hospitalizacion(self):
        """Con criterios de ambos niveles, debe prevalecer urgencia."""
        r = engine.evaluar(base(
            estado_consciencia=3,   # → urgencia
            edema_nutricional=1,    # → hospitalizacion
            ivnt_score=7.6          # → hospitalizacion
        ))
        assert r.nivel == 'urgencia'

    def test_hospitalizacion_supera_ambulatorio(self):
        r = engine.evaluar(base(
            edema_nutricional=1,    # → hospitalizacion
            ivnt_score=6.0          # → ambulatorio
        ))
        assert r.nivel == 'hospitalizacion'

    def test_ambulatorio_supera_casa(self):
        r = engine.evaluar(base(
            ivnt_score=5.5,         # → ambulatorio
            zscore_talla_edad=-1.5  # → casa
        ))
        assert r.nivel == 'ambulatorio'


# ── EVALUAR DESDE DICT ──────────────────────────────────────────────────────

class TestEvaluarDesdeDict:

    def test_dict_urgencia(self):
        r = engine.evaluar_desde_dict({'estado_consciencia': 3, 'ivnt_score': 9})
        assert r.nivel == 'urgencia'

    def test_dict_normal(self):
        r = engine.evaluar_desde_dict({})
        assert r.nivel == 'normal'

    def test_dict_con_campos_faltantes_no_explota(self):
        r = engine.evaluar_desde_dict({'hemoglobina': 6.0})
        assert r.nivel in ('urgencia','hospitalizacion','ambulatorio','casa','normal')


# ── RECOMENDACIONES Y ALERTAS ───────────────────────────────────────────────

class TestRecomendacionesAlertas:

    def test_recomendaciones_no_vacias(self):
        for nivel_datos in [
            base(convulsiones=True),
            base(edema_nutricional=1),
            base(ivnt_score=6.0),
            base(ivnt_score=3.0),
            base(),
        ]:
            r = engine.evaluar(nivel_datos)
            assert len(r.recomendaciones) > 0

    def test_alerta_edema_presente(self):
        r = engine.evaluar(base(edema_nutricional=1))
        mensajes = [a['mensaje'] for a in r.alertas]
        assert any('kwashiorkor' in m.lower() or 'edema' in m.lower() for m in mensajes)

    def test_alerta_muac_critico(self):
        r = engine.evaluar(base(muac_cm=11.0))
        assert any(a['nivel'] == 'CRITICO' for a in r.alertas)

    def test_recomendacion_mies_si_elcsa_alto(self):
        r = engine.evaluar(base(ivnt_score=3.0, score_elcsa=6))
        assert any('mies' in rec.lower() or 'bdh' in rec.lower()
                   for rec in r.recomendaciones)

    def test_acciones_inmediatas_presentes(self):
        r = engine.evaluar(base(convulsiones=True))
        assert len(r.acciones_inmediatas) > 0
