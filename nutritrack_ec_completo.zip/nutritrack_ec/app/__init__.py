from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Inicia sesión para continuar.'

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    db.init_app(app)
    login_manager.init_app(app)

    from app.routes.auth     import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.pacientes import pacientes_bp
    from app.routes.evaluacion import evaluacion_bp
    from app.routes.api      import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(pacientes_bp)
    app.register_blueprint(evaluacion_bp)
    app.register_blueprint(api_bp)

    with app.app_context():
        db.create_all()

    return app
