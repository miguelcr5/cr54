from flask import Blueprint, render_template
from flask_login import login_required

pacientes_bp = Blueprint('pacientes', __name__, url_prefix='/pacientes')

@pacientes_bp.route('/')
@login_required
def lista():
    return render_template('pacientes/lista.html')

@pacientes_bp.route('/nuevo')
@login_required
def nuevo():
    return render_template('pacientes/nuevo.html')
