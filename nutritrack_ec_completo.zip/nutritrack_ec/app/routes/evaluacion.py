from flask import Blueprint, render_template
from flask_login import login_required

evaluacion_bp = Blueprint('evaluacion', __name__, url_prefix='/evaluacion')

@evaluacion_bp.route('/<int:paciente_id>')
@login_required
def formulario(paciente_id):
    return render_template('evaluacion/formulario.html', paciente_id=paciente_id)
