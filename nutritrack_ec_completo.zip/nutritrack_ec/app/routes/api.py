"""
NUTRITRACK EC — API REST principal
Endpoint unificado: calcula IVNT + Triaje en una sola petición POST.
"""

from flask import Blueprint, request, jsonify
from datetime import date

from app.services.ivnt_engine   import IVNTEngine
from app.services.triage_engine import TriajeEngine
from app.models.paciente        import Paciente
from app.models.consulta        import Consulta
from app import db

api_bp = Blueprint('api', __name__, url_prefix='/api')

_ivnt   = IVNTEngine()
_triage = TriajeEngine()


# ────────────────────────────────────────────────
#  POST /api/evaluacion/calcular
#  Calcula IVNT + Triaje y guarda la consulta
# ────────────────────────────────────────────────
@api_bp.route('/evaluacion/calcular', methods=['POST'])
def calcular_evaluacion():
    """
    Body JSON esperado (todos los campos del formulario).

    Retorna:
      {
        "consulta_id": 42,
        "ivnt": { score, nivel, color_hex, da, db, dc, fvd, recomendaciones, alertas },
        "triage": { nivel, codigo, color, disposicion, descripcion,
                    tiempo_atencion, criterios_activados, alertas,
                    recomendaciones, acciones_inmediatas },
        "zscores": { zscore_talla_edad, zscore_peso_talla, zscore_peso_edad }
      }
    """
    datos = request.get_json(silent=True)
    if not datos:
        return jsonify({'error': 'Body JSON requerido'}), 400

    # ── Validar campos obligatorios ──
    obligatorios = ['paciente_id', 'peso_kg', 'talla_cm', 'edad_meses']
    faltantes = [c for c in obligatorios if c not in datos]
    if faltantes:
        return jsonify({'error': f'Campos requeridos: {faltantes}'}), 400

    paciente = Paciente.query.get(datos['paciente_id'])
    if not paciente:
        return jsonify({'error': 'Paciente no encontrado'}), 404

    # Agregar sexo al dict (viene del modelo, no del form)
    datos['sexo'] = paciente.sexo

    # Obtener historial previo para calcular FVD
    historial = [c.to_dict() for c in paciente.consultas.all()]

    # ── Capa 1: IVNT ──────────────────────────
    res_ivnt = _ivnt.calcular(datos, historial)
    datos['ivnt_score'] = res_ivnt.ivnt_final

    # ── Triaje ────────────────────────────────
    res_triage = _triage.evaluar_desde_dict(datos)

    # ── Guardar consulta ──────────────────────
    consulta = Consulta(
        paciente_id            = paciente.id,
        fecha_consulta         = date.today(),
        edad_meses             = datos['edad_meses'],
        peso_kg                = datos.get('peso_kg'),
        talla_cm               = datos.get('talla_cm'),
        muac_cm                = datos.get('muac_cm'),
        zscore_talla_edad      = datos.get('zscore_talla_edad'),
        zscore_peso_talla      = datos.get('zscore_peso_talla'),
        zscore_peso_edad       = datos.get('zscore_peso_edad'),
        velocidad_crecimiento  = datos.get('velocidad_crecimiento', 0),
        hemoglobina            = datos.get('hemoglobina'),
        peso_nacer_g           = datos.get('peso_nacer_g'),
        semanas_gestacion      = datos.get('semanas_gestacion'),
        episodios_diarrea_mes  = datos.get('episodios_diarrea_mes', 0),
        episodios_ira_mes      = datos.get('episodios_ira_mes', 0),
        lactancia_exclusiva    = datos.get('lactancia_exclusiva', 0),
        enf_cronica_nivel      = datos.get('enf_cronica_nivel', 0),
        score_elcsa            = datos.get('score_elcsa', 0),
        acceso_agua            = datos.get('acceso_agua', 0),
        saneamiento            = datos.get('saneamiento', 0),
        escolaridad_materna_anos = datos.get('escolaridad_materna_anos', 12),
        quintil_socioeconomico = datos.get('quintil_socioeconomico', 3),
        zona_consulta          = datos.get('zona_consulta', 0),
        ivnt_puntaje_a         = res_ivnt.puntaje_a,
        ivnt_puntaje_b         = res_ivnt.puntaje_b,
        ivnt_puntaje_c         = res_ivnt.puntaje_c,
        ivnt_score             = res_ivnt.ivnt_final,
        ivnt_nivel             = res_ivnt.nivel_riesgo,
        fvd                    = res_ivnt.fvd,
        recomendaciones_json   = str(res_ivnt.recomendaciones),
    )
    db.session.add(consulta)
    db.session.commit()

    # ── Respuesta ─────────────────────────────
    return jsonify({
        'consulta_id': consulta.id,
        'ivnt': {
            'score':           res_ivnt.ivnt_final,
            'nivel':           res_ivnt.nivel_riesgo,
            'color_hex':       res_ivnt.color_hex,
            'da':              res_ivnt.da_norm,
            'db':              res_ivnt.db_norm,
            'dc':              res_ivnt.dc_norm,
            'fvd':             res_ivnt.fvd,
            'recomendaciones': res_ivnt.recomendaciones,
            'alertas':         res_ivnt.alertas,
        },
        'triage': {
            'nivel':               res_triage.nivel,
            'codigo':              res_triage.codigo,
            'color':               res_triage.color,
            'color_hex':           res_triage.color_hex,
            'titulo':              res_triage.titulo,
            'disposicion':         res_triage.disposicion,
            'descripcion':         res_triage.descripcion,
            'tiempo_atencion':     res_triage.tiempo_atencion,
            'criterios_activados': res_triage.criterios_activados,
            'alertas':             res_triage.alertas,
            'recomendaciones':     res_triage.recomendaciones,
            'acciones_inmediatas': res_triage.acciones_inmediatas,
        },
    }), 200


# ────────────────────────────────────────────────
#  GET /api/paciente/<id>/historial
# ────────────────────────────────────────────────
@api_bp.route('/paciente/<int:paciente_id>/historial', methods=['GET'])
def historial_paciente(paciente_id):
    paciente = Paciente.query.get_or_404(paciente_id)
    consultas = paciente.consultas.order_by(Consulta.fecha_consulta.asc()).all()
    return jsonify({
        'paciente':  paciente.to_dict(),
        'consultas': [c.to_dict() for c in consultas],
    })


# ────────────────────────────────────────────────
#  GET /api/dashboard/stats
# ────────────────────────────────────────────────
@api_bp.route('/dashboard/stats', methods=['GET'])
def dashboard_stats():
    from sqlalchemy import func
    dist = db.session.query(
        Consulta.ivnt_nivel,
        func.count(Consulta.id).label('total')
    ).group_by(Consulta.ivnt_nivel).all()

    return jsonify({
        'total_pacientes':    Paciente.query.count(),
        'total_consultas':    Consulta.query.count(),
        'distribucion_riesgo': {row[0]: row[1] for row in dist},
    })
