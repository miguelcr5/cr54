"""
NUTRITRACK EC — Motor de Triaje Nutricional Pediátrico
=======================================================
5 niveles de disposición clínica:
  NIVEL I   — ROJO    : Urgencia inmediata (traslado hospitalario)
  NIVEL II  — NARANJA : Hospitalización / observación
  NIVEL III — AMARILLO: Manejo ambulatorio intensivo
  NIVEL IV  — VERDE   : Alta con seguimiento mensual
  NIVEL V   — AZUL    : Control rutinario (sin urgencia)

El triaje evalúa primero criterios de gravedad absolutos (independientes
del IVNT) y luego usa el puntaje IVNT como criterio de respaldo.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional


# ─────────────────────────────────────────────
#  Estructuras de datos
# ─────────────────────────────────────────────

@dataclass
class ResultadoTriage:
    nivel:          str          # urgencia | hospitalizacion | ambulatorio | casa | normal
    codigo:         str          # I | II | III | IV | V
    color:          str          # rojo | naranja | amarillo | verde | azul
    color_hex:      str
    titulo:         str
    disposicion:    str          # frase corta para mostrar al clínico
    descripcion:    str
    tiempo_atencion: str         # "< 15 min" | "< 30 min" | etc.
    criterios_activados: List[str] = field(default_factory=list)
    alertas:        List[Dict]   = field(default_factory=list)
    recomendaciones: List[str]   = field(default_factory=list)
    acciones_inmediatas: List[str] = field(default_factory=list)


@dataclass
class DatosTriaje:
    """
    Todos los campos necesarios para calcular el triaje.
    Los valores por defecto representan un niño sano promedio.
    """
    # ── Anthropométricos ──
    zscore_talla_edad:  float = 0.0
    zscore_peso_talla:  float = 0.0
    zscore_peso_edad:   float = 0.0
    muac_cm:            float = 14.0
    velocidad_crecimiento: int = 0   # 0=normal, 1=desacel.leve, 2=desacel.severa

    # ── Clínicos ──
    hemoglobina:           float = 12.0
    peso_nacer_g:          int   = 3000
    semanas_gestacion:     int   = 40
    episodios_diarrea_mes: int   = 0
    episodios_ira_mes:     int   = 0
    lactancia_exclusiva:   int   = 2   # 0=no tuvo, 1=parcial, 2=completa
    enf_cronica_nivel:     int   = 0   # 0=ninguna, 1=compensada, 2=descompensada

    # ── Signos de gravedad (nuevos para el triaje) ──
    estado_consciencia:    int   = 0   # 0=alerta, 1=irritable/somnoliento, 2=letárgico, 3=inconsciente
    edema_nutricional:     int   = 0   # 0=ausente, 1=bilateral leve, 2=bilateral severo (kwashiorkor)
    deshidratacion:        int   = 0   # 0=sin, 1=leve, 2=severa
    vomitos_persistentes:  int   = 0   # 0=no, 1=ocasionales, 2=frecuentes/incoercibles
    convulsiones:          bool  = False
    dificultad_respiratoria: bool = False
    fiebre_alta:           bool  = False   # >= 38.5 °C

    # ── Sociales ──
    score_elcsa:             int   = 0
    acceso_agua:             int   = 0   # 0=potable, 1=pozo, 2=ninguno
    saneamiento:             int   = 0
    escolaridad_materna_anos: int  = 12
    quintil_socioeconomico:  int   = 3
    zona_consulta:           int   = 0   # 0=urbana, 1=periurbana, 2=rural

    # ── IVNT (precalculado por IVNTEngine) ──
    ivnt_score: float = 0.0


# ─────────────────────────────────────────────
#  Motor principal
# ─────────────────────────────────────────────

class TriajeEngine:
    """
    Motor de triaje nutricional pediátrico de 5 niveles.

    Uso:
        from app.services.triage_engine import TriajeEngine, DatosTriaje

        datos = DatosTriaje(
            zscore_talla_edad=-2.1,
            zscore_peso_talla=-1.8,
            muac_cm=12.0,
            hemoglobina=9.5,
            estado_consciencia=0,
            ivnt_score=6.2,
            ...
        )
        engine = TriajeEngine()
        resultado = engine.evaluar(datos)
        print(resultado.nivel)          # "ambulatorio"
        print(resultado.disposicion)    # "El niño puede irse a casa — con seguimiento estrecho"
    """

    # ── Metadatos de niveles ──────────────────
    META = {
        'urgencia': {
            'codigo': 'I',
            'color': 'rojo',
            'color_hex': '#E24B4A',
            'titulo': 'Urgencia inmediata',
            'disposicion': 'El niño debe ir a urgencias AHORA',
            'descripcion': (
                'Riesgo vital o desnutrición severa con complicaciones. '
                'Traslado inmediato a emergencias hospitalarias. '
                'No puede irse a casa.'
            ),
            'tiempo_atencion': '< 15 minutos',
        },
        'hospitalizacion': {
            'codigo': 'II',
            'color': 'naranja',
            'color_hex': '#EF9F27',
            'titulo': 'Hospitalización / observación',
            'disposicion': 'El niño necesita hospitalización',
            'descripcion': (
                'Desnutrición severa sin complicación aguda inmediata, '
                'o con complicaciones controlables. Requiere ingreso hospitalario '
                'y manejo con fórmulas terapéuticas.'
            ),
            'tiempo_atencion': '< 30 minutos',
        },
        'ambulatorio': {
            'codigo': 'III',
            'color': 'amarillo',
            'color_hex': '#BA7517',
            'titulo': 'Manejo ambulatorio intensivo',
            'disposicion': 'El niño puede irse a casa — con seguimiento estrecho',
            'descripcion': (
                'Riesgo alto sin criterios de hospitalización. '
                'Alta condicional con derivación obligatoria a nutricionista '
                'y control en 15 días.'
            ),
            'tiempo_atencion': '< 2 horas (evaluación completa)',
        },
        'casa': {
            'codigo': 'IV',
            'color': 'verde',
            'color_hex': '#639922',
            'titulo': 'Alta con seguimiento',
            'disposicion': 'El niño puede irse a casa',
            'descripcion': (
                'Sin criterios de urgencia ni hospitalización. '
                'Control mensual. Orientación nutricional a la madre/cuidador.'
            ),
            'tiempo_atencion': 'Control rutinario',
        },
        'normal': {
            'codigo': 'V',
            'color': 'azul',
            'color_hex': '#378ADD',
            'titulo': 'Sin urgencia — Control rutinario',
            'disposicion': 'El niño está bien — Control rutinario',
            'descripcion': (
                'Estado nutricional normal. '
                'No hay urgencia. Próximo control en 2 meses según protocolo MSP.'
            ),
            'tiempo_atencion': 'Próxima cita programada',
        },
    }

    # ─────────────────────────────────────────
    #  NIVEL I — URGENCIA INMEDIATA (ROJO)
    # ─────────────────────────────────────────
    def _criterios_urgencia(self, d: DatosTriaje) -> List[str]:
        """
        Retorna lista de criterios de urgencia activados.
        Si la lista no está vacía → NIVEL I.
        """
        c = []
        if d.estado_consciencia >= 2:
            c.append('Alteración de consciencia (letárgico / inconsciente)')
        if d.convulsiones:
            c.append('Convulsiones activas o recientes')
        if d.dificultad_respiratoria:
            c.append('Dificultad respiratoria severa')
        if d.edema_nutricional >= 2:
            c.append('Edema bilateral severo — Kwashiorkor confirmado')
        if d.deshidratacion >= 2:
            c.append('Deshidratación severa')
        if d.zscore_peso_talla < -3:
            c.append('Z-score P/T < -3 DE (desnutrición aguda severa)')
        if d.muac_cm < 11.5:
            c.append('MUAC < 11.5 cm (umbral de emergencia)')
        if d.hemoglobina < 7.0:
            c.append('Hemoglobina < 7 g/dL (anemia severa)')
        if d.ivnt_score >= 8.5:
            c.append('IVNT ≥ 8.5 — riesgo crítico extremo')
        return c

    # ─────────────────────────────────────────
    #  NIVEL II — HOSPITALIZACIÓN (NARANJA)
    # ─────────────────────────────────────────
    def _criterios_hospitalizacion(self, d: DatosTriaje) -> List[str]:
        c = []
        if d.estado_consciencia == 1:
            c.append('Irritabilidad o somnolencia')
        if d.edema_nutricional == 1:
            c.append('Edema bilateral leve (riesgo de kwashiorkor)')
        if d.deshidratacion == 1:
            c.append('Deshidratación leve a moderada')
        if d.vomitos_persistentes == 2:
            c.append('Vómitos frecuentes / incoercibles')
        if d.fiebre_alta:
            c.append('Fiebre alta (≥ 38.5 °C) con desnutrición')
        if d.zscore_talla_edad < -3:
            c.append('Z-score T/E < -3 DE (desnutrición crónica severa)')
        if d.zscore_peso_talla < -2 and d.muac_cm < 12.5:
            c.append('Desnutrición aguda moderada + MUAC bajo (riesgo combinado)')
        if d.ivnt_score >= 7.5:
            c.append('IVNT ≥ 7.5 — riesgo crítico')
        return c

    # ─────────────────────────────────────────
    #  NIVEL III — AMBULATORIO INTENSIVO (AMARILLO)
    # ─────────────────────────────────────────
    def _criterios_ambulatorio(self, d: DatosTriaje) -> List[str]:
        c = []
        if d.ivnt_score >= 5.0:
            c.append(f'IVNT {d.ivnt_score:.1f} — riesgo alto')
        if d.zscore_talla_edad < -2:
            c.append('Desnutrición crónica establecida (T/E < -2 DE)')
        if d.velocidad_crecimiento == 2:
            c.append('Desaceleración severa de velocidad de crecimiento')
        if d.episodios_diarrea_mes >= 3:
            c.append('Diarrea frecuente (≥ 3 episodios/mes)')
        if d.hemoglobina < 10.0:
            c.append('Anemia moderada (Hb < 10 g/dL)')
        if d.muac_cm < 12.5:
            c.append('MUAC < 12.5 cm (riesgo nutricional significativo)')
        if d.score_elcsa >= 7:
            c.append('Inseguridad alimentaria severa (ELCSA ≥ 7)')
        return c

    # ─────────────────────────────────────────
    #  NIVEL IV — ALTA CON SEGUIMIENTO (VERDE)
    # ─────────────────────────────────────────
    def _criterios_casa(self, d: DatosTriaje) -> List[str]:
        c = []
        if d.ivnt_score >= 2.5:
            c.append(f'IVNT {d.ivnt_score:.1f} — riesgo moderado')
        if d.zscore_talla_edad < -1:
            c.append('Z-score T/E en zona de riesgo (-1 a -2 DE)')
        if d.hemoglobina < 11.0:
            c.append('Anemia leve (Hb 10-11 g/dL)')
        if d.velocidad_crecimiento == 1:
            c.append('Desaceleración leve de velocidad de crecimiento')
        if d.score_elcsa >= 3:
            c.append('Inseguridad alimentaria moderada (ELCSA ≥ 3)')
        if d.acceso_agua >= 1:
            c.append('Sin acceso a agua potable segura')
        if d.escolaridad_materna_anos < 9:
            c.append('Escolaridad materna baja (< 9 años)')
        return c

    # ─────────────────────────────────────────
    #  ALERTAS AUTOMÁTICAS
    # ─────────────────────────────────────────
    def _generar_alertas(self, d: DatosTriaje) -> List[Dict]:
        alertas = []

        if d.zscore_peso_talla < -3:
            alertas.append({
                'nivel': 'CRITICO',
                'tipo': 'anthropometrica',
                'icono': 'alert-triangle',
                'mensaje': 'Desnutrición aguda severa (Z P/T < -3 DE). Protocolo MSP inmediato.',
            })
        if d.muac_cm < 11.5:
            alertas.append({
                'nivel': 'CRITICO',
                'tipo': 'anthropometrica',
                'icono': 'alert-triangle',
                'mensaje': 'MUAC < 11.5 cm. Riesgo de desnutrición severa complicada.',
            })
        if d.hemoglobina < 7.0:
            alertas.append({
                'nivel': 'CRITICO',
                'tipo': 'clinica',
                'icono': 'heart-broken',
                'mensaje': 'Anemia severa (Hb < 7 g/dL). Manejo especializado urgente.',
            })
        if d.edema_nutricional >= 1:
            alertas.append({
                'nivel': 'ALTO',
                'tipo': 'clinica',
                'icono': 'droplet',
                'mensaje': 'Edema nutricional detectado. Kwashiorkor posible — evaluar albúmina.',
            })
        if d.estado_consciencia >= 2:
            alertas.append({
                'nivel': 'CRITICO',
                'tipo': 'neurologica',
                'icono': 'brain',
                'mensaje': 'Alteración de consciencia. Evaluación neurológica urgente.',
            })
        if d.convulsiones:
            alertas.append({
                'nivel': 'CRITICO',
                'tipo': 'neurologica',
                'icono': 'brain',
                'mensaje': 'Convulsiones reportadas. Glucemia urgente — descartar hipoglucemia.',
            })
        if d.zscore_talla_edad < -3:
            alertas.append({
                'nivel': 'ALTO',
                'tipo': 'anthropometrica',
                'icono': 'ruler',
                'mensaje': 'Desnutrición crónica severa (T/E < -3 DE). Referir a especialista.',
            })
        if d.score_elcsa >= 7:
            alertas.append({
                'nivel': 'MODERADO',
                'tipo': 'social',
                'icono': 'home-off',
                'mensaje': 'Inseguridad alimentaria severa. Activar red de protección social MIES.',
            })

        return alertas

    # ─────────────────────────────────────────
    #  RECOMENDACIONES POR NIVEL
    # ─────────────────────────────────────────
    def _recomendaciones(self, nivel: str, d: DatosTriaje) -> List[str]:
        base = {
            'urgencia': [
                'Activar protocolo de emergencias del MSP de inmediato.',
                'Traslado a unidad hospitalaria con capacidad de UCI pediátrica.',
                'Asegurar vía aérea permeable y oxigenoterapia si es necesario.',
                'Establecer acceso venoso y corregir glucemia (descartar hipoglucemia).',
                'Notificación urgente al epidemiólogo de área.',
                'Documentar la hora de triaje y de traslado.',
            ],
            'hospitalizacion': [
                'Ingreso hospitalario para manejo con fórmula F-75 en fase inicial.',
                'Corrección de complicaciones: infecciones, anemia, deshidratación.',
                'Transición a F-100 o RUTF en fase de rehabilitación nutricional.',
                'Evaluación por pediatra y nutricionista en las próximas 4 horas.',
                'Monitoreo de signos vitales y glucemia cada 2 horas.',
                'Coordinación con trabajo social para apoyo familiar.',
            ],
            'ambulatorio': [
                'Referencia a nutricionista clínico en los próximos 7 días (obligatorio).',
                'Iniciar RUTF o suplemento de micronutrientes según normativa MSP.',
                'Control antropométrico en 15 días para evaluar respuesta al tratamiento.',
                'Activar red de apoyo social comunitario (MIES / GAD).',
                'Capacitar a la madre sobre preparación y oferta adecuada de alimentos.',
                'Seguimiento telefónico en 72 horas para verificar cumplimiento.',
                'Tratar anemia si Hb < 11 g/dL: hierro terapéutico + vitamina C.',
            ],
            'casa': [
                'Alta a domicilio con orientación nutricional detallada a la madre.',
                'Control mensual estándar en el centro de salud.',
                'Consejería sobre lactancia materna y alimentación complementaria.',
                'Entrega de micronutrientes (chis paz) si corresponde por edad.',
                'Informar señales de alarma que requieren consulta urgente.',
                'Registrar en el padrón de niños con riesgo nutricional del establecimiento.',
            ],
            'normal': [
                'Control periódico cada 2 meses según protocolo MSP.',
                'Mantener lactancia materna exclusiva hasta los 6 meses.',
                'Alimentación complementaria adecuada a partir de los 6 meses.',
                'Verificar esquema de vacunación al día.',
                'Registro en ficha de seguimiento del Carné de Salud del Niño.',
            ],
        }

        recs = list(base.get(nivel, []))

        # Recomendaciones contextuales adicionales
        if d.score_elcsa >= 5:
            recs.append('Referir a programas de asistencia alimentaria (MIES / BDH).')
        if d.acceso_agua >= 1:
            recs.append('Gestionar acceso a agua segura con el GAD cantonal.')
        if d.escolaridad_materna_anos < 6:
            recs.append('Gestionar alfabetización o capacitación de la madre/cuidador.')

        return recs

    # ─────────────────────────────────────────
    #  ACCIONES INMEDIATAS (para mostrar en cabecera)
    # ─────────────────────────────────────────
    def _acciones_inmediatas(self, nivel: str) -> List[str]:
        acciones = {
            'urgencia': [
                'Llamar ambulancia / activar traslado',
                'Estabilizar al paciente',
                'Notificar epidemiólogo',
            ],
            'hospitalizacion': [
                'Coordinar cama hospitalaria',
                'Iniciar F-75',
                'Evaluación pediátrica < 4h',
            ],
            'ambulatorio': [
                'Emitir referencia a nutricionista',
                'Entregar RUTF / suplementos',
                'Agendar control en 15 días',
            ],
            'casa': [
                'Dar orientación nutricional',
                'Entregar micronutrientes',
                'Agendar control en 1 mes',
            ],
            'normal': [
                'Registrar control',
                'Verificar vacunas',
                'Agendar próxima cita',
            ],
        }
        return acciones.get(nivel, [])

    # ─────────────────────────────────────────
    #  PUNTO DE ENTRADA PÚBLICO
    # ─────────────────────────────────────────
    def evaluar(self, datos: DatosTriaje) -> ResultadoTriage:
        """
        Evalúa el triaje nutricional y retorna el ResultadoTriage completo.

        Lógica de prioridad (cascada):
          1. Si hay criterios de Nivel I  → urgencia
          2. Si hay criterios de Nivel II → hospitalizacion
          3. Si hay criterios de Nivel III→ ambulatorio
          4. Si hay criterios de Nivel IV → casa
          5. Sin criterios significativos → normal
        """
        # Evaluar niveles en cascada
        c1 = self._criterios_urgencia(datos)
        if c1:
            nivel, criterios = 'urgencia', c1
        else:
            c2 = self._criterios_hospitalizacion(datos)
            if c2:
                nivel, criterios = 'hospitalizacion', c2
            else:
                c3 = self._criterios_ambulatorio(datos)
                if c3:
                    nivel, criterios = 'ambulatorio', c3
                else:
                    c4 = self._criterios_casa(datos)
                    if c4:
                        nivel, criterios = 'casa', c4
                    else:
                        nivel = 'normal'
                        criterios = [
                            'Sin factores de riesgo significativos',
                            'Estado nutricional dentro de parámetros normales',
                        ]

        meta = self.META[nivel]

        return ResultadoTriage(
            nivel           = nivel,
            codigo          = meta['codigo'],
            color           = meta['color'],
            color_hex       = meta['color_hex'],
            titulo          = meta['titulo'],
            disposicion     = meta['disposicion'],
            descripcion     = meta['descripcion'],
            tiempo_atencion = meta['tiempo_atencion'],
            criterios_activados = criterios,
            alertas         = self._generar_alertas(datos),
            recomendaciones = self._recomendaciones(nivel, datos),
            acciones_inmediatas = self._acciones_inmediatas(nivel),
        )

    def evaluar_desde_dict(self, d: dict) -> ResultadoTriage:
        """
        Convierte un dict (p.ej. JSON de la API) a DatosTriaje y evalúa.
        Útil para el endpoint Flask sin instanciar DatosTriaje manualmente.
        """
        datos = DatosTriaje(
            zscore_talla_edad      = float(d.get('zscore_talla_edad', 0)),
            zscore_peso_talla      = float(d.get('zscore_peso_talla', 0)),
            zscore_peso_edad       = float(d.get('zscore_peso_edad', 0)),
            muac_cm                = float(d.get('muac_cm', 14)),
            velocidad_crecimiento  = int(d.get('velocidad_crecimiento', 0)),
            hemoglobina            = float(d.get('hemoglobina', 12)),
            peso_nacer_g           = int(d.get('peso_nacer_g', 3000)),
            semanas_gestacion      = int(d.get('semanas_gestacion', 40)),
            episodios_diarrea_mes  = int(d.get('episodios_diarrea_mes', 0)),
            episodios_ira_mes      = int(d.get('episodios_ira_mes', 0)),
            lactancia_exclusiva    = int(d.get('lactancia_exclusiva', 2)),
            enf_cronica_nivel      = int(d.get('enf_cronica_nivel', 0)),
            estado_consciencia     = int(d.get('estado_consciencia', 0)),
            edema_nutricional      = int(d.get('edema_nutricional', 0)),
            deshidratacion         = int(d.get('deshidratacion', 0)),
            vomitos_persistentes   = int(d.get('vomitos_persistentes', 0)),
            convulsiones           = bool(d.get('convulsiones', False)),
            dificultad_respiratoria= bool(d.get('dificultad_respiratoria', False)),
            fiebre_alta            = bool(d.get('fiebre_alta', False)),
            score_elcsa            = int(d.get('score_elcsa', 0)),
            acceso_agua            = int(d.get('acceso_agua', 0)),
            saneamiento            = int(d.get('saneamiento', 0)),
            escolaridad_materna_anos = int(d.get('escolaridad_materna_anos', 12)),
            quintil_socioeconomico = int(d.get('quintil_socioeconomico', 3)),
            zona_consulta          = int(d.get('zona_consulta', 0)),
            ivnt_score             = float(d.get('ivnt_score', 0)),
        )
        return self.evaluar(datos)
