"""
NUTRITRACK EC — Motor IVNT (Índice de Vulnerabilidad Nutricional Temprana)
Capa 1: funciona sin inteligencia artificial.

Fórmula:
  DA_norm = (puntaje_A / 13) × 10
  DB_norm = (puntaje_B / 14) × 10
  DC_norm = (puntaje_C / 12) × 10
  IVNT_base = DA_norm×0.40 + DB_norm×0.35 + DC_norm×0.25
  IVNT_final = IVNT_base × FVD   (máximo 10)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class ResultadoIVNT:
    puntaje_a:      float
    puntaje_b:      float
    puntaje_c:      float
    da_norm:        float
    db_norm:        float
    dc_norm:        float
    ivnt_base:      float
    fvd:            float
    ivnt_final:     float
    nivel_riesgo:   str
    color_hex:      str
    color_nombre:   str
    recomendaciones: List[str] = field(default_factory=list)
    alertas:        List[Dict] = field(default_factory=list)


class IVNTEngine:
    PESO_A = 0.40
    PESO_B = 0.35
    PESO_C = 0.25
    MAX_A  = 13
    MAX_B  = 14
    MAX_C  = 12

    COLORES = {
        'bajo':     ('#22c55e', 'Verde'),
        'moderado': ('#eab308', 'Amarillo'),
        'alto':     ('#f97316', 'Naranja'),
        'critico':  ('#ef4444', 'Rojo'),
    }

    # ------------------------------------------------------------------ #
    #  DOMINIO A — ANTHROPOMÉTRICO  (máx 13 pts)                          #
    # ------------------------------------------------------------------ #
    def dominio_a(self, d: dict) -> float:
        p = 0

        zte = d.get('zscore_talla_edad', 0)
        if   zte < -2.0: p += 3
        elif zte < -1.5: p += 2
        elif zte < -1.0: p += 1

        zpt = d.get('zscore_peso_talla', 0)
        if   zpt < -2.0: p += 3
        elif zpt < -1.5: p += 2
        elif zpt < -1.0: p += 1

        muac = d.get('muac_cm', 14.0)
        if   muac < 11.5: p += 3
        elif muac < 12.5: p += 2
        elif muac < 13.5: p += 1

        p += min(int(d.get('velocidad_crecimiento', 0)), 2)

        zpe = d.get('zscore_peso_edad', 0)
        if   zpe < -2.0: p += 2
        elif zpe < -1.0: p += 1

        return min(p, self.MAX_A)

    # ------------------------------------------------------------------ #
    #  DOMINIO B — CLÍNICO  (máx 14 pts)                                  #
    # ------------------------------------------------------------------ #
    def dominio_b(self, d: dict) -> float:
        p = 0

        hb = d.get('hemoglobina', 12.0)
        if   hb < 7.0:  p += 3
        elif hb < 10.0: p += 2
        elif hb < 11.0: p += 1

        bpn = d.get('peso_nacer_g', 3000)
        if   bpn < 1500: p += 2
        elif bpn < 2500: p += 1

        sge = d.get('semanas_gestacion', 40)
        if   sge < 34: p += 2
        elif sge < 37: p += 1

        diarrea = d.get('episodios_diarrea_mes', 0)
        if   diarrea >= 3: p += 2
        elif diarrea >= 1: p += 1

        ira = d.get('episodios_ira_mes', 0)
        if   ira >= 3: p += 2
        elif ira >= 1: p += 1

        lact = int(d.get('lactancia_exclusiva', 0))
        if   lact == 0: p += 2   # no tuvo
        elif lact == 1: p += 1   # parcial

        p += min(int(d.get('enf_cronica_nivel', 0)), 2)

        return min(p, self.MAX_B)

    # ------------------------------------------------------------------ #
    #  DOMINIO C — SOCIAL  (máx 12 pts)                                   #
    # ------------------------------------------------------------------ #
    def dominio_c(self, d: dict) -> float:
        p = 0

        elcsa = d.get('score_elcsa', 0)
        if   elcsa >= 7: p += 2
        elif elcsa >= 2: p += 1

        p += min(int(d.get('acceso_agua', 0)), 2)
        p += min(int(d.get('saneamiento', 0)), 2)

        escol = d.get('escolaridad_materna_anos', 12)
        if   escol < 6:  p += 2
        elif escol < 12: p += 1

        quintil = d.get('quintil_socioeconomico', 3)
        if   quintil <= 1: p += 2
        elif quintil <= 2: p += 1

        zona = int(d.get('zona_consulta', 0))
        p += min(zona, 2)

        return min(p, self.MAX_C)

    # ------------------------------------------------------------------ #
    #  FACTOR VELOCIDAD DETERIORO                                          #
    # ------------------------------------------------------------------ #
    def calcular_fvd(self, actual: dict,
                     historial: Optional[List[dict]] = None) -> float:
        if not historial:
            return 1.0
        ultima = historial[-1]
        n = 0
        if (actual.get('zscore_talla_edad', 0) -
                ultima.get('zscore_talla_edad', 0)) < -0.3:
            n += 1
        if (actual.get('zscore_peso_talla', 0) -
                ultima.get('zscore_peso_talla', 0)) < -0.3:
            n += 1
        if (actual.get('muac_cm', 14) -
                ultima.get('muac_cm', 14)) < -0.5:
            n += 1
        return min(1.0 + 0.15 * n, 1.45)

    # ------------------------------------------------------------------ #
    #  CLASIFICACIÓN                                                        #
    # ------------------------------------------------------------------ #
    def clasificar(self, ivnt: float):
        if ivnt < 2.5: key = 'bajo'
        elif ivnt < 5.0: key = 'moderado'
        elif ivnt < 7.5: key = 'alto'
        else: key = 'critico'
        hex_, nombre = self.COLORES[key]
        return key, hex_, nombre

    # ------------------------------------------------------------------ #
    #  RECOMENDACIONES                                                      #
    # ------------------------------------------------------------------ #
    def recomendaciones(self, nivel: str, d: dict) -> List[str]:
        base = {
            'bajo': [
                'Continuar controles periódicos según protocolo MSP (cada 2 meses).',
                'Promover lactancia materna y alimentación complementaria adecuada.',
                'Verificar esquema de vacunación al día.',
            ],
            'moderado': [
                'Control nutricional reforzado en 1 mes.',
                'Orientación nutricional a la madre/cuidador (consejería AIEPI).',
                'Verificar y tratar anemia si Hb < 11 g/dL.',
                'Registrar en padrón de niños con riesgo nutricional.',
            ],
            'alto': [
                'Referencia a nutricionista clínico en los próximos 7 días.',
                'Iniciar suplementación nutricional según normativa MSP.',
                'Control a los 15 días para evaluación de respuesta.',
                'Activar red de apoyo social comunitario.',
                'Notificar al equipo de salud del área.',
                'Si Hb < 11 g/dL: iniciar hierro terapéutico + vitamina C.',
            ],
            'critico': [
                'ACTIVAR PROTOCOLO MSP DE DESNUTRICIÓN AGUDA / CRÓNICA SEVERA.',
                'DERIVACIÓN URGENTE a nivel de mayor complejidad.',
                'Evaluar hospitalización si hay complicaciones.',
                'Notificación obligatoria al epidemiólogo de área.',
                'Coordinación con trabajo social para apoyo familiar.',
                'Vigilancia estrecha: control en máximo 7 días.',
            ],
        }
        recs = list(base.get(nivel, []))
        if d.get('score_elcsa', 0) >= 5:
            recs.append('Referir a programas de asistencia alimentaria (MIES / BDH).')
        if d.get('acceso_agua', 0) >= 1:
            recs.append('Gestionar acceso a agua segura con GAD cantonal.')
        return recs

    # ------------------------------------------------------------------ #
    #  ALERTAS AUTOMÁTICAS                                                  #
    # ------------------------------------------------------------------ #
    def alertas(self, d: dict) -> List[Dict]:
        a = []
        if d.get('zscore_peso_talla', 0) < -3:
            a.append({'nivel': 'CRITICO', 'tipo': 'anthropometrica',
                      'mensaje': 'Desnutrición aguda severa (Z P/T < -3 DE). Protocolo MSP inmediato.'})
        if d.get('muac_cm', 14) < 11.5:
            a.append({'nivel': 'CRITICO', 'tipo': 'anthropometrica',
                      'mensaje': 'MUAC < 11.5 cm. Riesgo de desnutrición severa complicada.'})
        if d.get('hemoglobina', 12) < 7:
            a.append({'nivel': 'ALTO', 'tipo': 'clinica',
                      'mensaje': 'Anemia severa (Hb < 7 g/dL). Manejo especializado urgente.'})
        if d.get('zscore_talla_edad', 0) < -3:
            a.append({'nivel': 'ALTO', 'tipo': 'anthropometrica',
                      'mensaje': 'Desnutrición crónica severa (Z T/E < -3 DE). Referir a especialista.'})
        return a

    # ------------------------------------------------------------------ #
    #  CALCULAR — punto de entrada público                                  #
    # ------------------------------------------------------------------ #
    def calcular(self, datos: dict,
                 historial: Optional[List[dict]] = None) -> ResultadoIVNT:
        pa = self.dominio_a(datos)
        pb = self.dominio_b(datos)
        pc = self.dominio_c(datos)

        da = (pa / self.MAX_A) * 10
        db = (pb / self.MAX_B) * 10
        dc = (pc / self.MAX_C) * 10

        base = da * self.PESO_A + db * self.PESO_B + dc * self.PESO_C
        fvd  = self.calcular_fvd(datos, historial)
        ivnt = min(round(base * fvd, 2), 10.0)

        nivel, hex_, nombre = self.clasificar(ivnt)

        return ResultadoIVNT(
            puntaje_a=pa, puntaje_b=pb, puntaje_c=pc,
            da_norm=round(da, 2), db_norm=round(db, 2), dc_norm=round(dc, 2),
            ivnt_base=round(base, 2), fvd=fvd, ivnt_final=ivnt,
            nivel_riesgo=nivel, color_hex=hex_, color_nombre=nombre,
            recomendaciones=self.recomendaciones(nivel, datos),
            alertas=self.alertas(datos),
        )
