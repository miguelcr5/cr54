from app import db
from datetime import datetime

class Paciente(db.Model):
    __tablename__ = 'pacientes'

    id               = db.Column(db.Integer, primary_key=True)
    codigo           = db.Column(db.String(20), unique=True, nullable=False)
    cedula           = db.Column(db.String(20))
    nombres          = db.Column(db.String(100), nullable=False)
    apellidos        = db.Column(db.String(100), nullable=False)
    fecha_nacimiento = db.Column(db.Date, nullable=False)
    sexo             = db.Column(db.String(1), nullable=False)   # M / F
    zona             = db.Column(db.String(20), default='urbana') # urbana|periurbana|rural
    provincia        = db.Column(db.String(50))
    canton           = db.Column(db.String(50))
    nombre_madre     = db.Column(db.String(150))
    telefono         = db.Column(db.String(20))
    created_at       = db.Column(db.DateTime, default=datetime.utcnow)

    consultas = db.relationship('Consulta', backref='paciente',
                                lazy='dynamic', order_by='Consulta.fecha_consulta')

    def edad_meses(self):
        from dateutil.relativedelta import relativedelta
        hoy = datetime.today().date()
        delta = relativedelta(hoy, self.fecha_nacimiento)
        return delta.years * 12 + delta.months

    def nombre_completo(self):
        return f'{self.nombres} {self.apellidos}'

    def to_dict(self):
        return {
            'id': self.id,
            'codigo': self.codigo,
            'nombre_completo': self.nombre_completo(),
            'fecha_nacimiento': self.fecha_nacimiento.isoformat(),
            'sexo': self.sexo,
            'zona': self.zona,
            'edad_meses': self.edad_meses(),
        }

    def __repr__(self):
        return f'<Paciente {self.codigo} - {self.nombre_completo()}>'
