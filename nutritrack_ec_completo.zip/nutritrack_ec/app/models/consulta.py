from app import db
from datetime import datetime

class Consulta(db.Model):
    __tablename__ = 'consultas'

    id             = db.Column(db.Integer, primary_key=True)
    paciente_id    = db.Column(db.Integer, db.ForeignKey('pacientes.id'), nullable=False)
    usuario_id     = db.Column(db.Integer, db.ForeignKey('usuarios.id'))
    fecha_consulta = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    edad_meses     = db.Column(db.Integer, nullable=False)

    # --- Dominio A: Anthropométrico ---
    peso_kg        = db.Column(db.Float)
    talla_cm       = db.Column(db.Float)
    muac_cm        = db.Column(db.Float)
    imc            = db.Column(db.Float)

    # Z-scores calculados
    zscore_talla_edad  = db.Column(db.Float)
    zscore_peso_talla  = db.Column(db.Float)
    zscore_peso_edad   = db.Column(db.Float)
    zscore_imc_edad    = db.Column(db.Float)

    # Velocidad crecimiento (0=normal, 1=leve, 2=severa)
    velocidad_crecimiento = db.Column(db.Integer, default=0)

    # --- Dominio B: Clínico ---
    hemoglobina           = db.Column(db.Float)
    peso_nacer_g          = db.Column(db.Integer)
    semanas_gestacion     = db.Column(db.Integer)
    episodios_diarrea_mes = db.Column(db.Integer, default=0)
    episodios_ira_mes     = db.Column(db.Integer, default=0)
    lactancia_exclusiva   = db.Column(db.Integer, default=0)  # 0=no,1=parcial,2=completa
    enfermedad_cronica    = db.Column(db.String(200))
    enf_cronica_nivel     = db.Column(db.Integer, default=0)  # 0=ninguna,1=comp,2=descomp

    # --- Dominio C: Social ---
    score_elcsa             = db.Column(db.Integer, default=0)
    acceso_agua             = db.Column(db.Integer, default=0)  # 0=potable,1=pozo,2=ninguno
    saneamiento             = db.Column(db.Integer, default=0)  # 0=alcant,1=letrina,2=campo
    escolaridad_materna_anos = db.Column(db.Integer, default=12)
    quintil_socioeconomico  = db.Column(db.Integer, default=3)
    zona_consulta           = db.Column(db.Integer, default=0)  # 0=urbana,1=periurb,2=rural

    # --- IVNT calculado ---
    ivnt_puntaje_a  = db.Column(db.Float)
    ivnt_puntaje_b  = db.Column(db.Float)
    ivnt_puntaje_c  = db.Column(db.Float)
    ivnt_score      = db.Column(db.Float)
    ivnt_nivel      = db.Column(db.String(20))   # bajo|moderado|alto|critico
    fvd             = db.Column(db.Float, default=1.0)

    # --- IA ---
    ia_probabilidad = db.Column(db.Float)
    ia_nivel_riesgo = db.Column(db.String(20))
    ia_shap_json    = db.Column(db.Text)

    recomendaciones_json = db.Column(db.Text)
    created_at           = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'fecha_consulta': self.fecha_consulta.isoformat(),
            'edad_meses': self.edad_meses,
            'peso_kg': self.peso_kg,
            'talla_cm': self.talla_cm,
            'muac_cm': self.muac_cm,
            'zscore_talla_edad': self.zscore_talla_edad,
            'zscore_peso_talla': self.zscore_peso_talla,
            'zscore_peso_edad': self.zscore_peso_edad,
            'hemoglobina': self.hemoglobina,
            'ivnt_score': self.ivnt_score,
            'ivnt_nivel': self.ivnt_nivel,
        }
