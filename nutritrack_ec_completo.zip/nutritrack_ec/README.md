# NUTRITRACK EC v1.0
**Sistema Inteligente de Detección Temprana y Triaje Nutricional Pediátrico**

---

## Levantar el proyecto en VS Code

### 1. Clonar / descomprimir el proyecto
```
nutritrack_ec/
├── run.py
├── config.py
├── requirements.txt
├── app/
│   ├── models/      ← Paciente, Consulta, Usuario
│   ├── routes/      ← auth, dashboard, pacientes, evaluacion, api
│   └── services/    ← ivnt_engine.py  ←  triage_engine.py
└── tests/
    └── test_triage_engine.py
```

### 2. Crear entorno virtual
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac / Linux
source venv/bin/activate
```

### 3. Instalar dependencias
```bash
pip install -r requirements.txt
pip install python-dateutil   # para cálculo de edad en meses
```

### 4. Variables de entorno (opcional)
Crear archivo `.env` en la raíz:
```
SECRET_KEY=mi-clave-secreta-segura
DATABASE_URL=sqlite:///nutritrack.db
```

### 5. Inicializar la base de datos
```bash
python run.py
# La BD se crea automáticamente en instance/nutritrack.db
```

### 6. Ejecutar el servidor
```bash
python run.py
# → http://localhost:5000
```

### 7. Ejecutar los tests
```bash
pip install pytest
pytest tests/test_triage_engine.py -v
```

---

## Archivos clave que puedes modificar

| Archivo | Qué puedes cambiar |
|---|---|
| `app/services/ivnt_engine.py` | Pesos del IVNT (0.40/0.35/0.25), umbrales de z-score, puntajes por variable |
| `app/services/triage_engine.py` | Umbrales de triaje, criterios por nivel, recomendaciones |
| `app/models/paciente.py` | Campos del registro de paciente |
| `app/models/consulta.py` | Campos de la consulta nutricional |
| `config.py` | Base de datos (SQLite → PostgreSQL), debug, secret key |

---

## Endpoint principal de la API

```
POST /api/evaluacion/calcular
Content-Type: application/json

{
  "paciente_id": 1,
  "edad_meses": 18,
  "peso_kg": 8.5,
  "talla_cm": 74.0,
  "muac_cm": 12.4,
  "zscore_talla_edad": -1.8,
  "zscore_peso_talla": -1.2,
  "zscore_peso_edad": -1.5,
  "hemoglobina": 10.2,
  "estado_consciencia": 0,
  "edema_nutricional": 0,
  "deshidratacion": 0,
  "episodios_diarrea_mes": 2,
  "score_elcsa": 5,
  "acceso_agua": 1,
  "ivnt_score": 5.7
}
```

**Respuesta:**
```json
{
  "consulta_id": 42,
  "ivnt": {
    "score": 5.7,
    "nivel": "alto",
    "color_hex": "#f97316",
    "recomendaciones": ["..."],
    "alertas": []
  },
  "triage": {
    "nivel": "ambulatorio",
    "codigo": "III",
    "color": "amarillo",
    "disposicion": "El niño puede irse a casa — con seguimiento estrecho",
    "criterios_activados": ["IVNT 5.7 — riesgo alto"],
    "acciones_inmediatas": ["Emitir referencia a nutricionista", "..."]
  }
}
```

---

## Niveles de triaje

| Código | Color | Disposición | Tiempo de atención |
|---|---|---|---|
| I | Rojo | Urgencias AHORA | < 15 minutos |
| II | Naranja | Hospitalización | < 30 minutos |
| III | Amarillo | Alta con seguimiento estrecho | < 2 horas |
| IV | Verde | Alta a domicilio | Control en 1 mes |
| V | Azul | Control rutinario | Control en 2 meses |

---

## Migrar a PostgreSQL (producción)

En `config.py`, cambiar:
```python
SQLALCHEMY_DATABASE_URI = 'postgresql://usuario:clave@localhost/nutritrack_db'
```
No se necesita cambiar nada más — SQLAlchemy abstrae el motor de BD.
