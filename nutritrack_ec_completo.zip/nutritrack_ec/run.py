from app import create_app, db
from app.models.usuario import Usuario
from app.models.paciente import Paciente
from app.models.consulta import Consulta

app = create_app('development')

@app.shell_context_processor
def make_shell_context():
    return dict(db=db, Usuario=Usuario, Paciente=Paciente, Consulta=Consulta)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
